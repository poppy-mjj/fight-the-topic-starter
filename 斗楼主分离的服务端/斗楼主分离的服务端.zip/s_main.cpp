#include "s_Game.h"

int main() {
	Game Mine;
	while (1)
	{
		Mine.Run();
	}
}